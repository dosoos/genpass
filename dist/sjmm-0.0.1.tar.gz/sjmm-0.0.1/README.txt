# What Is genpass
 generation a random password

# How To Install?
```sh
$ pip install genpass
```

# How To Use?
import genpass
genpass.gen() or genpass.gen(10)

## example:
```sh
$ genpass.gen(10, type=1)
$ 8214465316
```

```sh
$ genpass.gen(10, type=2)
$ wsqsteyqml
```


```sh
$ genpass.gen(10, type=3)
$ 8bvgotpiex
```


```sh
$ genpass.gen(10, type=4)
$ CQPOADQCZH
```


```sh
$ genpass.gen(10, type=5)
$ 9X5215N66X
```


```sh
$ genpass.gen(10, type=8)
$ |[=}-'*=[]
```


```sh
$ genpass.gen(10, type=9)
$ |*6"|8-`$>
```

etc.

bit and
[8] [4] [2] [1]
1.digits
2.lowercase
4.uppercase
8.punctuation


## all done, thinks read this!
